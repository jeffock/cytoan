from .preprocessutils import foo

def faa() -> int:
	return 0
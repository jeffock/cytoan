from .preprocessutils import channel_select

def foo() -> int:
	print("foo running")
	return 0
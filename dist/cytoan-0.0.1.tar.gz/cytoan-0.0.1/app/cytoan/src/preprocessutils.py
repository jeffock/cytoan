
def foo() -> int 
	return 0